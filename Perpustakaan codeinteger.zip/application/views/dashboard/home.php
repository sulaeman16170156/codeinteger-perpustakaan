<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" href="2.css">
</head>

<body class="ahai">
	<h1>HOME</h1>
</body>
</html>