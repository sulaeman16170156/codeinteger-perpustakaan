<div class="content-wrapper">
    <div class="container">
      <section class="content-header">
        <h1>
          <?=$title;?>
          <small><?=$sub_title;?></small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Dashboard</a></li>
          <li class="active">Current Page</li>
        </ol>
      </section>